/**
 * Source code from the Java Parallel Programming Coursera course.
 */
package edu.coursera.parallel;
